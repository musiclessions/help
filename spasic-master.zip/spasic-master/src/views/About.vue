<template>
  <div class="container about">
    <div class="row">
      <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Name</h5>
            <i class="fas fa-signature"></i>
            <a class="card-text">Tran Dang Khoa</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Email</h5>
            <i class="fas fa-envelope-square"></i>
            <a class="card-text">kohatd13@gmail.com</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Facebook</h5>
            <i class="fab fa-facebook"></i>
            <a href="https://fb.com/koha1310" class="card-text">fb.com/koha1310</a>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Github</h5>
            <i class="fab fa-github-square"></i>
            <a href="https://github.com/koha13" class="card-text">github.com/koha13</a>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <img src="../assets/girl.png" alt style="width:100%" />
    </div>
  </div>
</template>
<style scoped>
.about {
  margin-top: 85px;
  max-width: 70%;
  margin-bottom: 80px;
}
i {
  padding-right: 5px;
}
</style>
